function register_number_keys() {
	tizen.tvinputdevice.registerKey('0');
	tizen.tvinputdevice.registerKey('1');
	tizen.tvinputdevice.registerKey('2');
	tizen.tvinputdevice.registerKey('3');
	tizen.tvinputdevice.registerKey('4');
	tizen.tvinputdevice.registerKey('5');
	tizen.tvinputdevice.registerKey('6');
	tizen.tvinputdevice.registerKey('7');
	tizen.tvinputdevice.registerKey('8');
	tizen.tvinputdevice.registerKey('9');
	tizen.tvinputdevice.registerKey('ChannelUp');
	tizen.tvinputdevice.registerKey('ChannelDown');
}